-- Coordinates in local metres. Gate widths/precise locations are model approximations.
return {
 S=1/.28,
 Zones={
  {Name='Baseball',Label='野球場',Height=3.5,
   Polygon={{-89,-118},{105,-118},{105,75},{-89,75}},
   Gates={
    {Name='西門',A={-89,-24},B={-89,-17},Outside={-94.2,-20.5},Inside={-83,-20.5}},
    {Name='東門',A={105,-24.5},B={105,-17.5},Outside={111.5,-21},Inside={99,-21}},
   }},
  {Name='Athletics',Label='陸上競技場',Height=1.1,
   Polygon={{124,-133},{304,-133},{304,-35},{124,-35}},
   Gates={
    {Name='南西門',A={124,-53.5},B={124,-46.5},Outside={111.4,-50},Inside={131,-50}},
    {Name='北西門',A={128.5,-133},B={135.5,-133},Outside={132,-154},Inside={132,-126}},
   }},
  {Name='Grove',Label='屋敷森',Height=1.96,
   Polygon={{85.2,191.8},{49.3,192.4},{48.5,140.5},{104.2,140},{94.5,181.5},{86,181.5}},
   Gates={{Name='入口',A={59.7,140.39946},B={62.3,140.37612},Outside={61,138.8},Inside={61,145}}},
  },
 }
}
