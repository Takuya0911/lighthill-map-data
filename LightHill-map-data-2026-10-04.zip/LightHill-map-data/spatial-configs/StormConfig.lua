-- Metres in the ParkMapData coordinate system. World studs = metres / 0.28.
-- Candidates follow existing paved paths; each kind can appear in any region.
local supplyCandidates = {
	{ XZ = Vector2.new(111.7, -153.8), Region = "NE", Area = "北東の遊び場周辺", AreaKey = "playground" },
	{ XZ = Vector2.new(89.9, -251.1), Region = "NE", Area = "北東の林間道", AreaKey = "northeast_woods" },
	{ XZ = Vector2.new(225.1, -322.4), Region = "NE", Area = "北東の遊び場より北の道", AreaKey = "north_of_playground" },
	{ XZ = Vector2.new(-258.5, -229.5), Region = "NW", Area = "北西の林間道", AreaKey = "northwest_woods" },
	{ XZ = Vector2.new(-323.2, -307.5), Region = "NW", Area = "北のあずまや周辺", AreaKey = "north_roof" },
	{ XZ = Vector2.new(-398.4, -158.9), Region = "NW", Area = "芝生広場の北西側", AreaKey = "northwest_lawn" },
	{ XZ = Vector2.new(-222.3, 88.8), Region = "SW", Area = "芝生広場の南東側", AreaKey = "southeast_lawn" },
	{ XZ = Vector2.new(-373, 92.1), Region = "SW", Area = "芝生広場の西側", AreaKey = "west_lawn" },
	{ XZ = Vector2.new(-298.7, 240.7), Region = "SW", Area = "南西の鳥の森外周", AreaKey = "southwest_bird_forest" },
	{ XZ = Vector2.new(304.4, -153.4), Region = "E", Area = "東側の長い遊歩道", AreaKey = "east_path" },
	{ XZ = Vector2.new(304.4, -29.4), Region = "E", Area = "東側の遊歩道の曲がり角", AreaKey = "east_corner" },
	{ XZ = Vector2.new(-94.1, -126.2), Region = "C", Area = "中央の十字路", AreaKey = "central_crossroads" },
	{ XZ = Vector2.new(-136.2, -21.6), Region = "C", Area = "中央のあずまや南側の道", AreaKey = "south_of_central_roof" },
	{ XZ = Vector2.new(-148.8, -364), Region = "N", Area = "北入口の並木道", AreaKey = "north_avenue" },
	{ XZ = Vector2.new(-30.6, 315.3), Region = "S", Area = "南側の並木道", AreaKey = "south_avenue" },
	{ XZ = Vector2.new(-126.1, 214), Region = "S", Area = "南側の広場へ続く道", AreaKey = "south_square_path" },
}
return {
	Duration = 600,
	RainAt = 90,
	StormAt = 240,
	ResultDuration = 18,
	MaximumPlayers = 4,
	MetresPerStud = 0.28,
	-- One shared starting area per round, on existing paved paths.
	StartSites = {
		{ Id = "NW", XZ = Vector2.new(-398, -330.1), Name = "北西の外周路" },
		{ Id = "N", XZ = Vector2.new(-69, -354.3), Name = "北の並木道" },
		{ Id = "NE", XZ = Vector2.new(170.8, -367), Name = "北東の外周路" },
		{ Id = "E", XZ = Vector2.new(304.4, -29.4), Name = "東の遊歩道" },
		{ Id = "C", XZ = Vector2.new(-136.2, -21.6), Name = "中央の並木道" },
		{ Id = "SE", XZ = Vector2.new(88.6, 81.6), Name = "野球場南の道" },
		{ Id = "W", XZ = Vector2.new(-442.1, 133.4), Name = "芝生広場西の外周路" },
		{ Id = "SW", XZ = Vector2.new(-298.7, 240.7), Name = "鳥の森北側の道" },
	},
	-- A compact 2x2 group; every slot remains inside even a 5m-wide path.
	StartOffsets = { Vector2.new(-.56,-.56), Vector2.new(.56,-.56), Vector2.new(-.56,.56), Vector2.new(.56,.56) },
	ShelterXZ = Vector2.new(-178, 352),
	ShelterRadiusMetres = 8,
	PickupDistanceStuds = 12,
	PickupHoldSeconds = 1.3,
	MinimumStartDistanceMetres = 100,
	MinimumGoalDistanceMetres = 75,
	MinimumSupplyDistanceMetres = 60,
	MinimumSameKindDistanceMetres = 150,
	-- Even a fully known solo route must cross at least 1 km, including hidden finds.
	MinimumSoloRouteMetres = 1000,
	HiddenSupplyChance = .35,
	ReturnAid = { EmergencyAt = 90, EnergyDuration = 30, NormalBars = 4 },
	Survival = {
		WalkSpeed = 16, RunSpeed = 28, ExhaustedSpeed = 12,
		SprintDrain = 14, WalkRecovery = 10, RestRecovery = 18,
		ExhaustionRecovery = 25,
		RainExposure = 0.45, StormExposure = 0.85, ShelterRecovery = 4,
		RaincoatExposureMultiplier = 0.3,
		ColdThreshold = 70, ColdSpeedMultiplier = 0.8,
		RainMudMultiplier = 0.85, StormMudMultiplier = 0.68,
		FloodSpeedMultiplier = 0.5, FloodExposure = 2,
	},
	-- Six base items always satisfy requirements for one to four players.
	-- Only the first of each kind is hinted; a third may spawn without a clue.
	SupplyPools = {
		Light = supplyCandidates,
		Battery = supplyCandidates,
		Raincoat = supplyCandidates,
	},
	RainShelters = {
		{ XZ = Vector2.new(-215, 355), RadiusMetres = 3.5, Name = "南入口の雨宿りテント", BuildRoof = true },
		{ XZ = Vector2.new(-333.4, -307), RadiusMetres = 2, Name = "北のあずまや" },
		{ XZ = Vector2.new(-397.1, -72.3), RadiusMetres = 3.5, Name = "芝生西のあずまや" },
		{ XZ = Vector2.new(-145.7, -58.5), RadiusMetres = 3.5, Name = "中央のあずまや" },
		{ XZ = Vector2.new(-296.3, -219.2), RadiusMetres = 3.5, Name = "北西の休憩屋根" },
	},
	Hazards = {
		{ XZ = Vector2.new(-338, -217), SizeMetres = Vector2.new(24, 14), Name = "北西芝生の冠水" },
		{ XZ = Vector2.new(-344, -102), SizeMetres = Vector2.new(38, 22), Name = "西芝生の冠水" },
	},
}
