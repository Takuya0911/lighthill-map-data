-- Original fictional oddities, positioned against the existing park geometry.
return {MetresPerStud=.28,Sites={
{Id="ToiletWest",Kind="Toilet",CFrame=CFrame.lookAt(Vector3.new(-1413.555908,10.974277,-502.507385),Vector3.new(-1413.177734,10.974277,-503.433136)),WidthStuds=4.8000,HeightStuds=5.1000,TriggerMetres=24.00},
{Id="ToiletEast",Kind="Toilet",CFrame=CFrame.lookAt(Vector3.new(358.125000,6.950000,-564.690063),Vector3.new(358.125000,6.950000,-565.690063)),WidthStuds=4.8000,HeightStuds=5.1000,TriggerMetres=24.00},
{Id="ToiletNorth",Kind="Toilet",CFrame=CFrame.lookAt(Vector3.new(704.076233,6.601185,-1151.828735),Vector3.new(703.587219,6.601185,-1152.701050)),WidthStuds=4.8000,HeightStuds=5.1000,TriggerMetres=24.00},
{Id="GroveWell",Kind="Grove",CFrame=CFrame.lookAt(Vector3.new(265.357147,0.698938,651.428589),Vector3.new(265.357147,0.698938,652.428589)),WidthStuds=2.3000,HeightStuds=3.2000,TriggerMetres=18.00}
}}
