Light Hill map data — 2026-10-04

© OpenStreetMap contributors. ODbL 1.0. Full license and attribution included.
Contains original OSM extraction, current ParkMapData (73 paths, 49 areas, 27 buildings, 16 places), 1638 paved path samples and spatial configuration tables for gates, toilets, shelters and gameplay locations.
Map strings verified against the current Studio XML snapshot; all places and spatial tables extracted directly from that snapshot.
Local metre coordinates and Roblox conversion: COORDINATES.json. Lua data tables use Vector2/Vector3/CFrame syntax; additional fields explain usage. Gates and toilet footprints are approximations. This is a fictional game map, not a surveyed official map.
Independent game logic, UI, audio, GSI imagery/DEM/vegetation and the complete game are not included.
Public distribution: https://github.com/Takuya0911/lighthill-map-data
The game remains separately distributed on Roblox.
